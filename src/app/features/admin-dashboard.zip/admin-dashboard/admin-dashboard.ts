import { Component, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { inject } from '@angular/core';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-admin-dashboard',
  imports: [CommonModule, RouterModule, ButtonModule, RippleModule],
  templateUrl: './admin-dashboard.html',
  styleUrl: './admin-dashboard.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminDashboard {
  private authService = inject(AuthService);

  sidebarVisible = signal<boolean>(true);
  currentUser = this.authService.currentUser;

  menuItems = [
    { label: 'Projects', icon: 'pi pi-th-large', route: 'projects' },
    { label: 'Testimonials', icon: 'pi pi-comments', route: 'testimonials' },
    { label: 'Refunds', icon: 'pi pi-receipt', route: 'refunds' },
    { label: 'Back to Site', icon: 'pi pi-arrow-left', route: '/home' },
  ];

  logout() {
    this.authService.logout().subscribe();
  }
}
