import { Component, OnInit, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TestimonialService } from '../../../../core/services/testimonial.service';
import { ApiTestimonial } from '../../../../core/interface/testimonial.interface';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { RatingModule } from 'primeng/rating';
import { FormsModule } from '@angular/forms';
import { MessageService, ConfirmationService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToastModule } from 'primeng/toast';
import { TooltipModule } from 'primeng/tooltip';

@Component({
  selector: 'app-testimonials-management',
  standalone: true,
  imports: [
    CommonModule,
    TableModule,
    ButtonModule,
    RatingModule,
    FormsModule,
    ConfirmDialogModule,
    ToastModule,
    TooltipModule
  ],
  providers: [MessageService, ConfirmationService],
  templateUrl: './testimonials.html',
  styleUrl: './testimonials.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TestimonialsManagement implements OnInit {
  private testimonialService = inject(TestimonialService);
  private messageService = inject(MessageService);
  private confirmationService = inject(ConfirmationService);

  testimonials = signal<ApiTestimonial[]>([]);
  loading = signal<boolean>(false);

  ngOnInit() {
    this.loadTestimonials();
  }

  loadTestimonials() {
    this.loading.set(true);
    this.testimonialService.getAllTestimonials().subscribe({
      next: (res) => {
        if (res.success) {
          this.testimonials.set(res.data);
        }
        this.loading.set(false);
      },
      error: () => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Failed to load testimonials' });
        this.loading.set(false);
      }
    });
  }

  approveTestimonial(testimonial: ApiTestimonial) {
    this.testimonialService.approveTestimonial(testimonial._id).subscribe({
      next: () => {
        this.loadTestimonials();
        this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Testimonial approved' });
      },
      error: () => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Failed to approve testimonial' });
      }
    });
  }

  deleteTestimonial(testimonial: ApiTestimonial) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete this testimonial?',
      header: 'Confirm Deletion',
      icon: 'pi pi-exclamation-triangle',
      acceptButtonStyleClass: 'p-button-danger p-button-text',
      rejectButtonStyleClass: 'p-button-text p-button-plain',
      accept: () => {
        this.testimonialService.deleteTestimonial(testimonial._id).subscribe({
          next: () => {
            this.loadTestimonials();
            this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Testimonial deleted' });
          },
          error: () => {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Failed to delete testimonial' });
          }
        });
      }
    });
  }

  getAuthorName(userId: any): string {
    if (typeof userId === 'object' && userId !== null) {
      return userId.name || 'Anonymous';
    }
    return 'Anonymous';
  }
}
